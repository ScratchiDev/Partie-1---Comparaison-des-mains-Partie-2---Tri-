import java.util.*;

public class PokerHand implements Comparable<PokerHand> {

    private final String[] cartes;
    private static final Map<Character, Integer> VALEURS;

    static {
        Map<Character, Integer> valeurs = new HashMap<>();
        valeurs.put('2', 2);
        valeurs.put('3', 3);
        valeurs.put('4', 4);
        valeurs.put('5', 5);
        valeurs.put('6', 6);
        valeurs.put('7', 7);
        valeurs.put('8', 8);
        valeurs.put('9', 9);
        valeurs.put('T', 10);
        valeurs.put('J', 11);
        valeurs.put('Q', 12);
        valeurs.put('K', 13);
        valeurs.put('A', 14);
        VALEURS = Collections.unmodifiableMap(valeurs);
    }

    public PokerHand(String main) {
        this.cartes = main.split(" ");
        Arrays.sort(this.cartes, Comparator.comparingInt(carte -> VALEURS.get(carte.charAt(0))));
    }

    public Result comparerAvec(PokerHand autre) {
        int rangCetteMain = evaluerRang(this.cartes);
        int rangAutreMain = evaluerRang(autre.cartes);

        if (rangCetteMain > rangAutreMain) {
            return Result.GAGNE;
        } else if (rangCetteMain < rangAutreMain) {
            return Result.PERDU;
        } else {
            return Result.EGALITE;
        }
    }

    @Override
    public int compareTo(PokerHand autre) {
        int rangCetteMain = evaluerRang(this.cartes);
        int rangAutreMain = evaluerRang(autre.cartes);

        return Integer.compare(rangAutreMain, rangCetteMain);
    }

    private int evaluerRang(String[] cartes) {
        return VALEURS.get(cartes[4].charAt(0));
    }

    @Override
    public String toString() {
        return Arrays.toString(cartes);
    }

    public static void main(String[] args) {
        PokerHand main1 = genererMainAleatoire();
        PokerHand main2 = genererMainAleatoire();

        System.out.println("Main 1: " + main1);
        System.out.println("Main 2: " + main2);

        Result resultat = main1.comparerAvec(main2);
        System.out.println("Résultat de la comparaison: " + resultat);
    }

    private static PokerHand genererMainAleatoire() {
        List<String> deck = new ArrayList<>();
        for (char valeur : VALEURS.keySet()) {
            for (char couleur : new char[]{'S', 'H', 'D', 'C'}) {
                deck.add("" + valeur + couleur);
            }
        }
        Collections.shuffle(deck);

        String[] main = new String[5];
        for (int i = 0; i < 5; i++) {
            main[i] = deck.get(i);
        }

        return new PokerHand(String.join(" ", main));
    }
}

enum Result {
    GAGNE,
    PERDU,
    EGALITE
}
